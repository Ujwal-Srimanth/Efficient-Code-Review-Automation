// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TopNav from './components/TopNav';
import Sidebar from './components/Sidebar';
import About from './components/About';
import ReviewCode from './components/ReviewCode';
import Analysis from './components/Analysis';
import ContactUs from './components/ContactUs'; // Import the ContactUs component
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
    return (
        <Router>
            <div className="d-flex flex-column" style={{ minHeight: '100vh' }}>
                <TopNav />
                <div className="d-flex flex-grow-1">
                    <Sidebar />
                    <div className="flex-grow-1 p-3">
                        <Routes>
                            <Route path="/about" element={<About />} />
                            <Route path="/review" element={<ReviewCode />} />
                            <Route path="/analysis" element={<Analysis />} />
                            <Route path="/contact" element={<ContactUs />} /> {/* Add the route for Contact Us */}
                            <Route path="/" element={<About />} />
                        </Routes>
                    </div>
                </div>
            </div>
        </Router>
    );
};

export default App;
