// src/components/About.js
import React from 'react';
import { Carousel } from 'react-bootstrap'; // Ensure react-bootstrap is installed

const About = () => {
    return (
        <div className="min-vh-100 d-flex flex-column bg-dark text-white">
            <div className="container my-5">
                <h1 className="mb-5 text-center">About CodeReviewer Tool</h1>
                
                <div className="px-lg-5 mx-auto" style={{ maxWidth: '90%' }}>
                    <Carousel className="mb-5 shadow bg-secondary">
                        <Carousel.Item>
                            <div className="p-4">
                                <h3>Automated Code Analysis</h3>
                                <p>
                                    Our tool automates the code analysis process, identifying issues and suggesting improvements.
                                </p>
                            </div>
                        </Carousel.Item>
                        <Carousel.Item>
                            <div className="p-4">
                                <h3>Seamless Integrations</h3>
                                <p>
                                    Integrates seamlessly with GitHub, GitLab, Bitbucket, and more for a smooth workflow.
                                </p>
                            </div>
                        </Carousel.Item>
                    </Carousel>
                </div>

                <p className="lead mb-5">
                    CodeReviewer Tool is a sophisticated platform designed to streamline the code review process, enhancing code quality and developer collaboration. It provides automated code analysis, facilitates peer review, and integrates with various version control systems.
                </p>

                <div className="row g-4">
                    <div className="col-lg-6">
                        <h2>Key Features</h2>
                        <ul>
                            <li>Real-time code quality analysis and feedback.</li>
                            <li>Collaborative review process with threaded discussions.</li>
                            <li>Integration with major version control systems.</li>
                        </ul>
                    </div>
                    <div className="col-lg-6">
                        <h2>Why Choose Us?</h2>
                        <ul>
                            <li>Enhance code quality and consistency across your projects.</li>
                            <li>Reduce time spent on manual code reviews.</li>
                            <li>Improve team collaboration and knowledge sharing.</li>
                            <li>Track and measure improvement over time with insightful metrics.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default About;
