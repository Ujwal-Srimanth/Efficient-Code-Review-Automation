// src/components/Sidebar.js
import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
    return (
        <div className="d-flex flex-column bg-dark text-white" style={{ width: '250px', height: '10000px' }}>
            <ul className="nav nav-pills flex-column mb-auto">
                <li className="nav-item">
                    <Link to="/review" className="nav-link text-white">
                        <i className="bi bi-code-slash"></i> Review Code
                    </Link>
                </li>
                <li className="nav-item">
                    <Link to="/analysis" className="nav-link text-white">
                        <i className="bi bi-graph-up"></i> Analysis
                    </Link>
                </li>
            </ul>
        </div>
    );
};

export default Sidebar;
