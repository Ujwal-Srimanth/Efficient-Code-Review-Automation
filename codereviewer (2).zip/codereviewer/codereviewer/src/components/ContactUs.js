import React, { useState } from 'react';

const ContactUs = () => {
    const [members, setMembers] = useState([
        {
            id: 1,
            name: 'AKHILA',
            role: 'Frontend developer and Supervisor',
            description: 'A passionate Front-End Developer with a keen eye for design and a drive for creating seamless user experiences. Crafting responsive and visually appealing web applications using modern technologies like React, JavaScript, HTML, and CSS.',
            image: 'akhila.jpg',
        },
        {
            id: 2,
            name: 'Siddharth',
            role: 'Team lead and Backend Developer',
            description: 'Your dedicated team leader. My role involves overseeing project planning, resource allocation, and ensuring that our development efforts align with business goals. I foster a collaborative environment where creativity thrives, and together, we deliver high-quality software solutions on time and within budget.',
            image: 'sid.png',
        },
        {
            id: 3,
            name: 'Ujwal',
            role: 'Backend Developer',
            description: 'Our backend development team, led by experienced professionals, ensures that the server-side of our applications runs smoothly. We excel in languages like Python, Node.js, and Java, managing databases efficiently, and maintaining the overall integrity and performance of our systems.',
            image: 'sri.jpg',
        },
        {
            id: 4,
            name: 'Senthen maru',
            role: 'Research staff and Documentation',
            description: 'Expert in backend technologies and database management. Skilled in optimizing server performance and ensuring data security. Passionate about building scalable and robust systems that meet business requirements.',
            image: 'sen.png',
        },
        {
            id: 5,
            name: 'Aishwarya',
            role: 'UI designer',
            description: 'Creative UI/UX designer with a focus on user-centered design principles. Proficient in creating intuitive and visually appealing interfaces that enhance user experience. Skilled in tools like Adobe XD, Figma, and Sketch.',
            image: 'aish.jpg',
        },
        {
            id: 6,
            name: 'Anuswethaa',
            role: ' Research staff',
            description: 'Collaborative and result-driven . Dedicated to fostering teamwork, guiding team members, and ensuring project success. Skilled in project management methodologies and effective communication.',
            image: 'anu.jpg',
        },
    ]);

    const handleClick = (id) => {
        const updatedMembers = members.map(member =>
            member.id === id ? { ...member, showDescription: !member.showDescription } : member
        );
        setMembers(updatedMembers);
    };

    return (
        <div className="container-fluid mt-5" style={{ backgroundColor: '#212529', color: '#fff', minHeight: '90vh' }}>
            <h2 className="mb-4 text-center">Contact Us</h2>
            <div className="row">
                {members.map((member, index) => (
                    <div key={member.id} className={`col-md-4 mb-5 ${index > 2 ? 'mt-4' : ''}`}>
                        <div 
                            className="card shadow-sm"
                            style={{
                                cursor: 'pointer',
                                backgroundColor: '#fff',
                                transition: 'transform 0.3s ease-in-out',
                            }}
                            onClick={() => handleClick(member.id)}
                            onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.05)')}
                            onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                        >
                            {!member.showDescription ? (
                                <img
                                    src={member.image}
                                    className="card-img-top rounded-circle"
                                    alt={member.name}
                                    style={{ width: '100px', height: '100px', objectFit: 'cover' }}
                                />
                            ) : (
                                <div className="card-body">
                                    <p>{member.description}</p>
                                </div>
                            )}
                            <div className="card-body">
                                <h5 className="card-title">{member.name}</h5>
                                <p className="card-text">{member.role}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ContactUs;
