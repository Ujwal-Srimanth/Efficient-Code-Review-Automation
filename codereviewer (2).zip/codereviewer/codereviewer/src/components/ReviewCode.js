import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ReviewCode = () => {
  const [repoLink, setRepoLink] = useState('');
  const [lineNumbers, setLineNumbers] = useState('all lines');
  const [fileUploaded, setFileUploaded] = useState(false);
  const [isZip, setIsZip] = useState(false);
  const [acceptedFile, setAcceptedFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleRepoLinkChange = (e) => setRepoLink(e.target.value);
  const handleLineNumbersChange = (e) => setLineNumbers(e.target.value);
  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile) {
      const fileName = uploadedFile.name;
      const fileExtension = fileName.split('.').pop().toLowerCase();
      if (['py', 'java', 'zip'].includes(fileExtension)) {
        setAcceptedFile(uploadedFile);
        setFileUploaded(true);
        setIsZip(fileExtension === 'zip');
      } else {
        alert('Only Python (.py), Java (.java), and ZIP (.zip) files are accepted!');
      }
    }
  };

  const handleUpload = async () => {
    if (!acceptedFile) {
      alert('Please select a file to upload.');
      return;
    }

    setIsLoading(true);
    const formData = new FormData();
    formData.append('file', acceptedFile);
    formData.append('lines', lineNumbers);

    try {
      const uploadResponse = await axios.post('http://localhost:3001/upload', formData);
      if (uploadResponse.status === 200) {
        alert('Submission successful! Redirecting to analysis page...');
        navigate('/analysis', { state: { key: new Date().getTime() } }); 
      } else {
        alert('Upload failed! Check the server logs for details.');
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Upload failed! Check the console for details.');
    } finally {
      setIsLoading(false);
      setFileUploaded(false);
      setAcceptedFile(null);
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-start pt-3" style={{ minHeight: '100vh', backgroundColor: '#212529' }}>
      <div className="card shadow-lg" style={{ width: '100%', maxWidth: '600px', backgroundColor: '#2c3034' }}>
        <div className="card-body text-light">
          <h2 className="card-title text-center">Review Code</h2>
          {/* <div className="mb-3">
            <label htmlFor="githubRepo" className="form-label">GitHub Repository Link</label>
            <input
              type="text"
              className="form-control"
              id="githubRepo"
              placeholder="Enter GitHub repository link"
              value={repoLink}
              onChange={handleRepoLinkChange}
            />
          </div> */}
          <div className="mb-3">
            <label htmlFor="fileInput" className="form-label">Upload File</label>
            <input
              type="file"
              className="form-control"
              id="fileInput"
              onChange={handleFileUpload}
            />
          </div>
          {!isZip && fileUploaded && (
            <div className="mb-4">
              <label htmlFor="lineNumbers" className="form-label">Line Numbers (comma-separated)</label>
              <input
                type="text"
                className="form-control"
                id="lineNumbers"
                placeholder="Line Numbers (comma-separated)"
                value={lineNumbers}
                onChange={handleLineNumbersChange}
              />
            </div>
          )}
      <button className="btn btn-primary w-100" onClick={handleUpload}>Upload & Review</button>
      {isLoading && <div>Loading analysis data, waiting for code review to complete...</div>}
    </div>
    </div>
    </div>
  );
};

export default ReviewCode;
