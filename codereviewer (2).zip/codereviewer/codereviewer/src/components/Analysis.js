import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const Analysis = () => {
  const [reviewResults, setReviewResults] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchReviewResults = async () => {
    try {
      const response = await axios.get('http://localhost:3001/review-status');
      if (response.data && response.data.state === 'Completed') {
        setReviewResults(response.data);
        setIsLoading(false);
      } else if (response.data.state === 'Pending') {
        setReviewResults(null);
        setIsLoading(true);
      }
    } catch (error) {
      console.error('Error fetching review results:', error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReviewResults();
    const intervalId = setInterval(fetchReviewResults, 30000); // Poll every 30 seconds
    return () => clearInterval(intervalId);
  }, []);

  if (isLoading) {
    return <div className="alert alert-info">Loading analysis data, please wait...</div>;
  }

  if (!reviewResults) {
    return <div className="alert alert-warning">Waiting for the review to be completed...</div>;
  }

  return (
    <div className="container my-5">
      <div className="card bg-dark text-white">
        <div className="card-header">
          <h2>Analysis Results</h2>
        </div>
        <div className="card-body">
          {reviewResults.recommendations && reviewResults.recommendations.length > 0 ? (
            reviewResults.recommendations.map((rec, index) => (
              <div key={index} className="mb-3 p-3 bg-secondary rounded">
                <h5>Description</h5>
                <p>{rec.Description}</p>
                <h5>Category</h5>
                <p>{rec.RecommendationCategory}</p>
                <h5>Severity</h5>
                <p>{rec.Severity}</p>
              </div>
            ))
          ) : (
            <div className="alert alert-secondary">No recommendations found</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Analysis;
